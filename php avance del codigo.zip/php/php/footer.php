<?php
// footer.php - Pie de página
?>
  <footer class="footer">
    <div class="footer-top">
      <div class="footer-brand">
        <a href="index.php" class="logo-box footer-logo">Logo</a>
        <div class="social-icons">
          <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="#" aria-label="Twitter"><i class="fa-brands fa-x-twitter"></i></a>
        </div>
      </div>

      <div class="footer-links-group">
        <div class="footer-col">
          <h5>Tienda</h5>
          <ul>
            <li><a href="shop.php">Té Negro</a></li>
            <li><a href="shop.php">Té Verde</a></li>
            <li><a href="shop.php">Infusiones</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h5>Compañía</h5>
          <ul>
            <li><a href="#">Nosotros</a></li>
            <li><a href="#">Sostenibilidad</a></li>
            <li><a href="#">Contacto</a></li>
          </ul>
        </div>
      </div>

      <div class="footer-newsletter">
        <h5>Únete a nuestra comunidad</h5>
        <form class="newsletter-form" onsubmit="event.preventDefault(); alert('¡Suscrito!');">
          <input type="email" placeholder="Tu correo electrónico..." required />
          <button type="submit" class="btn btn-outline">Suscribirse</button>
        </form>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; <?php echo date("Y"); ?> Tu Tienda Online. Todos los derechos reservados.</p>
    </div>
  </footer>

  <script src="script.js"></script>
</body>
</html>