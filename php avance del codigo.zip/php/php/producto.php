<?php
$pageTitle = "Detalle del Producto | E-Commerce Wireframe";
include 'header.php';
?>

<main>
  <nav class="breadcrumb-container">
    <a href="index.php">Inicio</a> &gt; 
    <a href="shop.php">Tienda</a> &gt; 
    <span>Té Negro Earl Grey Imperial</span>
  </nav>

  <section class="product-detail-section">
    <!-- Link de imagen amarilla grande -->
    <div class="product-detail-media">
      <a href="https://placehold.co/800x800/e5d8be/7b6d57?text=Imagen+Detalle+Producto" class="img-link main-image-link" target="_blank" title="Ampliar imagen">
        <img src="https://placehold.co/800x800/e5d8be/7b6d57?text=Imagen" alt="Detalle del Producto" class="img-fluid detail-main-img" />
      </a>
    </div>

    <!-- Detalles del Producto -->
    <div class="product-detail-info">
      <h1>Nombre</h1>
      <div class="product-rating">
        <div class="stars">
          <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i>
        </div>
        <span class="rating-count">(28 opiniones)</span>
      </div>

      <div class="detail-price">$18.50</div>

      <div class="detail-description">
        <p>Una infusión rica y aromática elaborada con hojas de té negro cosechadas en las colinas de Ceilán, aromatizadas con bergamota italiana.</p>
      </div>

      <div class="detail-option-group">
        <label>Presentación:</label>
        <div class="option-buttons">
          <button type="button" class="option-btn active">100g (Lata)</button>
          <button type="button" class="option-btn">250g (Bolsa)</button>
        </div>
      </div>

      <div class="detail-actions">
        <div class="quantity-control">
          <button type="button" class="qty-btn" onclick="decreaseQty()">-</button>
          <input type="number" id="detail-qty" value="1" min="1" />
          <button type="button" class="qty-btn" onclick="increaseQty()">+</button>
        </div>
        <a href="cart.php" class="btn btn-dark btn-lg">Añadir al carrito</a>
      </div>
    </div>
  </section>

  <!-- Sección de 4 Productos Relacionados -->
  <section class="featured-section">
    <div class="featured-header">
      <h2>Título</h2>
      <p>También te podría interesar</p>
    </div>

    <div class="products-grid four-cols">
      <?php for ($i = 1; $i <= 4; $i++): ?>
      <article class="product-card">
        <a href="product.php" class="img-link" title="Ver producto">
          <img src="https://placehold.co/400x300/e5d8be/7b6d57?text=Imagen" alt="Relacionado <?php echo $i; ?>" class="img-fluid product-img" />
        </a>
        <div class="product-info">
          <h3>Nombre</h3>
          <p>Producto complementario de la colección.</p>
          <a href="product.php" class="btn btn-dark btn-block">Ver producto</a>
        </div>
      </article>
      <?php endfor; ?>
    </div>
  </section>
</main>

<script>
  function increaseQty() { const input = document.getElementById('detail-qty'); input.value = parseInt(input.value) + 1; }
  function decreaseQty() { const input = document.getElementById('detail-qty'); if (parseInt(input.value) > 1) input.value = parseInt(input.value) - 1; }
</script>

<?php include 'footer.php'; ?>
