<?php
// header.php - Encabezado reutilizable
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo isset($pageTitle) ? $pageTitle : "E-Commerce Store"; ?></title>
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
</head>
<body>

  <aside class="announcement-bar">
    <p>Envío gratis en compras mayores a $50 | Atención al cliente: +1 800 123 4567</p>
  </aside>

 
  <header class="navbar">
    <div class="nav-left">
      <a href="index.php" class="logo-box">Logo</a>
      <nav class="nav-links">
        <a href="shop.php">Shop</a>
        <a href="index.php#subscribe">Subscribe</a>
        <a href="index.php#about">About</a>
      </nav>
    </div>
    <div class="nav-right">
      <div class="search-container">
        <i class="fa-solid fa-magnifying-glass search-icon"></i>
        <input type="text" placeholder="Search store..." />
      </div>
      <a href="cart.php" class="cart-icon-btn" title="Ver carrito">
        <i class="fa-solid fa-bag-shopping"></i>
        <span class="cart-badge">1</span>
      </a>
    </div>
  </header>